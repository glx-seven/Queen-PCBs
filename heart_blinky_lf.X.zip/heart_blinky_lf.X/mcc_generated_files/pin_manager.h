/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.6
        Device            :  PIC16LF18326
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.30 and above
        MPLAB 	          :  MPLAB X 5.40	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set IO_LD4 aliases
#define IO_LD4_TRIS                 TRISAbits.TRISA4
#define IO_LD4_LAT                  LATAbits.LATA4
#define IO_LD4_PORT                 PORTAbits.RA4
#define IO_LD4_WPU                  WPUAbits.WPUA4
#define IO_LD4_OD                   ODCONAbits.ODCA4
#define IO_LD4_ANS                  ANSELAbits.ANSA4
#define IO_LD4_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define IO_LD4_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define IO_LD4_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define IO_LD4_GetValue()           PORTAbits.RA4
#define IO_LD4_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define IO_LD4_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define IO_LD4_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define IO_LD4_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define IO_LD4_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define IO_LD4_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define IO_LD4_SetAnalogMode()      do { ANSELAbits.ANSA4 = 1; } while(0)
#define IO_LD4_SetDigitalMode()     do { ANSELAbits.ANSA4 = 0; } while(0)

// get/set IO_LD5 aliases
#define IO_LD5_TRIS                 TRISAbits.TRISA5
#define IO_LD5_LAT                  LATAbits.LATA5
#define IO_LD5_PORT                 PORTAbits.RA5
#define IO_LD5_WPU                  WPUAbits.WPUA5
#define IO_LD5_OD                   ODCONAbits.ODCA5
#define IO_LD5_ANS                  ANSELAbits.ANSA5
#define IO_LD5_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define IO_LD5_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define IO_LD5_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define IO_LD5_GetValue()           PORTAbits.RA5
#define IO_LD5_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define IO_LD5_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define IO_LD5_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define IO_LD5_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define IO_LD5_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define IO_LD5_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define IO_LD5_SetAnalogMode()      do { ANSELAbits.ANSA5 = 1; } while(0)
#define IO_LD5_SetDigitalMode()     do { ANSELAbits.ANSA5 = 0; } while(0)

// get/set IO_LD6 aliases
#define IO_LD6_TRIS                 TRISCbits.TRISC0
#define IO_LD6_LAT                  LATCbits.LATC0
#define IO_LD6_PORT                 PORTCbits.RC0
#define IO_LD6_WPU                  WPUCbits.WPUC0
#define IO_LD6_OD                   ODCONCbits.ODCC0
#define IO_LD6_ANS                  ANSELCbits.ANSC0
#define IO_LD6_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define IO_LD6_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define IO_LD6_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define IO_LD6_GetValue()           PORTCbits.RC0
#define IO_LD6_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define IO_LD6_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define IO_LD6_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define IO_LD6_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define IO_LD6_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define IO_LD6_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define IO_LD6_SetAnalogMode()      do { ANSELCbits.ANSC0 = 1; } while(0)
#define IO_LD6_SetDigitalMode()     do { ANSELCbits.ANSC0 = 0; } while(0)

// get/set IO_LD7 aliases
#define IO_LD7_TRIS                 TRISCbits.TRISC1
#define IO_LD7_LAT                  LATCbits.LATC1
#define IO_LD7_PORT                 PORTCbits.RC1
#define IO_LD7_WPU                  WPUCbits.WPUC1
#define IO_LD7_OD                   ODCONCbits.ODCC1
#define IO_LD7_ANS                  ANSELCbits.ANSC1
#define IO_LD7_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define IO_LD7_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define IO_LD7_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define IO_LD7_GetValue()           PORTCbits.RC1
#define IO_LD7_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define IO_LD7_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define IO_LD7_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define IO_LD7_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define IO_LD7_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define IO_LD7_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define IO_LD7_SetAnalogMode()      do { ANSELCbits.ANSC1 = 1; } while(0)
#define IO_LD7_SetDigitalMode()     do { ANSELCbits.ANSC1 = 0; } while(0)

// get/set IO_LD1 aliases
#define IO_LD1_TRIS                 TRISCbits.TRISC2
#define IO_LD1_LAT                  LATCbits.LATC2
#define IO_LD1_PORT                 PORTCbits.RC2
#define IO_LD1_WPU                  WPUCbits.WPUC2
#define IO_LD1_OD                   ODCONCbits.ODCC2
#define IO_LD1_ANS                  ANSELCbits.ANSC2
#define IO_LD1_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define IO_LD1_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define IO_LD1_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define IO_LD1_GetValue()           PORTCbits.RC2
#define IO_LD1_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define IO_LD1_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define IO_LD1_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define IO_LD1_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define IO_LD1_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define IO_LD1_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define IO_LD1_SetAnalogMode()      do { ANSELCbits.ANSC2 = 1; } while(0)
#define IO_LD1_SetDigitalMode()     do { ANSELCbits.ANSC2 = 0; } while(0)

// get/set IO_LD2 aliases
#define IO_LD2_TRIS                 TRISCbits.TRISC3
#define IO_LD2_LAT                  LATCbits.LATC3
#define IO_LD2_PORT                 PORTCbits.RC3
#define IO_LD2_WPU                  WPUCbits.WPUC3
#define IO_LD2_OD                   ODCONCbits.ODCC3
#define IO_LD2_ANS                  ANSELCbits.ANSC3
#define IO_LD2_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define IO_LD2_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define IO_LD2_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define IO_LD2_GetValue()           PORTCbits.RC3
#define IO_LD2_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define IO_LD2_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define IO_LD2_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define IO_LD2_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define IO_LD2_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define IO_LD2_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define IO_LD2_SetAnalogMode()      do { ANSELCbits.ANSC3 = 1; } while(0)
#define IO_LD2_SetDigitalMode()     do { ANSELCbits.ANSC3 = 0; } while(0)

// get/set IO_LD3 aliases
#define IO_LD3_TRIS                 TRISCbits.TRISC4
#define IO_LD3_LAT                  LATCbits.LATC4
#define IO_LD3_PORT                 PORTCbits.RC4
#define IO_LD3_WPU                  WPUCbits.WPUC4
#define IO_LD3_OD                   ODCONCbits.ODCC4
#define IO_LD3_ANS                  ANSELCbits.ANSC4
#define IO_LD3_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define IO_LD3_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define IO_LD3_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define IO_LD3_GetValue()           PORTCbits.RC4
#define IO_LD3_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define IO_LD3_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define IO_LD3_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define IO_LD3_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define IO_LD3_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define IO_LD3_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define IO_LD3_SetAnalogMode()      do { ANSELCbits.ANSC4 = 1; } while(0)
#define IO_LD3_SetDigitalMode()     do { ANSELCbits.ANSC4 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/